<footer>
        <p>&copy; <?= date("Y") ?> My Blog</p>
    </footer>
</body>
</html>
